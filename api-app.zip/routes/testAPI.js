var express = require('express');
var router = express.Router();
var User = require('../models/users');

router.get('/', function(req, res, next) {
    res.send('API is working properly');
});

router.post('/', function(req, res, next) {

    const dataToForm = {
        name: req.body.name,
        token: req.body.token,
        email: req.body.email,
        provider: req.body.provider,
        providerId: req.body.provider_id,
        providerPic: req.body.provider_pic
    }

    const user = new User(dataToForm);

    // find each person with a last name matching 'Ghost', selecting the `name` and `occupation` fields
    User.findOne({ 'email': dataToForm.email, 'provider': dataToForm.provider }, function(err, userCame) {
        if (userCame && userCame.email && userCame.id) {
            res.json(userCame);
        } else {
            user.save()
                .then(data => {
                    res.json(data);
                })
                .catch(err => {
                    res.json({ message: err });
                });

        }
    });




});

module.exports = router;